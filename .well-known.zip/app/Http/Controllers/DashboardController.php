<?php

namespace App\Http\Controllers;

use App\Models\Unit;
use App\Models\User;
use Illuminate\View\View;
use App\Models\Enrollment;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index(Request $request): mixed
    {
        if($request->unit_id) {
            $enrollments = Enrollment::where('unit_id', $request->unit_id)->paginate();
        } else {
            $enrollments = Enrollment::paginate();
        }
        $units = Unit::all();
        return view('dashboard', [
            'enrollments' => $enrollments,
            'units' => $units
        ]);
    }
}
