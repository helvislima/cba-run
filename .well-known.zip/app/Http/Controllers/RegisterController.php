<?php

namespace App\Http\Controllers;

use App\Models\Unit;
use App\Models\User;
use Illuminate\View\View;
use App\Models\Enrollment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use App\Mail\SendUserConfirmedEnrollmentEmail;

class RegisterController extends Controller
{
    public function register(Request $request): mixed
    {
        $code = $request->code;
        $user = null;
        if($code) {
            $user = User::where('code', $code)->first();
            if(!$user) {
                return redirect()->back()->withError(['Esta matrícula não existe']);
            }
        }
        return view('welcome', [
            'user' => $user
        ]);
    }

    public function store(Request $request)
    {
        $user = User::where('code', $request->code)->first();
        if($user) {
            $totalRegistered = Enrollment::where('unit_id', $user->unit_id)->count();
            $availableVacancie = Unit::where('id', $user->unit_id)->first()->vacancies;
            if(($totalRegistered + 1) <= $availableVacancie) {
                $hasEnrollment = Enrollment::where('user_id', $user->id)->exists();
                if($hasEnrollment) {
                    return redirect()->back()->withError(['Você já realizou esta inscrição']);
                } else {
                    $enrollment = Enrollment::create([
                        'user_id' => $user->id,
                        'user_name' => $user->name,
                        'unit_id' => $user->unit_id,
                        'unit' => $user->unit,
                        'tshirt' => null,
                        'phone' => $request->phone,
                        'email' => $request->email
                    ]);

                    //Mail::to($request->email)->send(new SendUserConfirmedEnrollmentEmail($user, $enrollment));    
                    return redirect()->back()->withSuccess(['Sua inscrição foi efetuada com sucesso!']);
                }
            } else {
                return redirect()->back()->withError(['O número de vagas foi atingido para esta unidade']);
            }
        }
    }

}
