<?php echo e($slot); ?>

<?php /**PATH /home1/cativida/cba.catividade.com.br/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>