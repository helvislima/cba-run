<?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => $__env->getContainer()->make(Illuminate\View\Factory::class)->make('mail::message'),'data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('mail::message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<p>Olá <?php echo e($user->name); ?>,</p>
<p>Sua inscrição foi concluída! Parabéns, o seu primeiro passo pela diversidade foi dado.</p>
<p><strong>Domingo, Dia 28 de Maio de 2023</strong></p>
<p>Não esqueça de se preparar, baixe o Strava ou prepare o  APP e GPS de sua preferência, para registrar sua corrida.</p>
<hr>
<h3>Seus dados cadastrados:</h3>
<strong>Unidade</strong>: <?php echo e($user->unit); ?><br>
<strong>Tamanho de camisa</strong>: <?php echo e($enrollment->tshirt); ?><br>
<strong>Telefone: </strong><?php echo e($enrollment->phone); ?><br>
<br>
Obrigado,<br>
<?php echo e(env('APP_NAME')); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
<?php /**PATH /home1/cativida/cba.catividade.com.br/resources/views/enrollment.blade.php ENDPATH**/ ?>