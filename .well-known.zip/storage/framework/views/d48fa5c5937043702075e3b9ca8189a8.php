<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GuestLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <center><h7><strong>Formulário de Inscrição</strong></h7></center>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
        <?php if(!request()->query('code')): ?>
            <form method="GET" action="">
                <?php if(session('error')): ?>
                    <div class="mt-3 alert alert-danger alert-dismissible show" role="alert">
                        <span class="alert-icon"><i class="ni ni-like-2"></i></span>
                        <span class="alert-text"><strong>Erro!</strong> <?php echo e(session('error')[0]); ?></span>
                    </div>
                <?php endif; ?>
                <?php echo csrf_field(); ?>
                <div class="mt-4">
                    <label>Digite sua Matrícula (somente números)</label>
                    <input <?php if(request()->query('code')): ?> readonly <?php endif; ?> id="name" class="form-control block mt-1 w-full" type="number" name="code" value="<?php echo e(request()->query('code')); ?>" required/>
                </div>
                <?php if(!request()->query('code')): ?>
                <div class="card mt-2 " style="font-size: 13px">
                    <div class="card-body">
                        <strong>Corrida virtual 5km - Domingo, Dia 28/05/2023</strong><br>
                        Seu percurso deverá ser registrado por GPS ou aplicativos de corrida e, ser publicado com print de imagem com o tempo da corrida através do link que enviaremos via e-mail.
                        <br>Boa corrida à todos e todas!
                    </div>
                </div>
                <div class="flex items-center justify-end mt-4">
                    <button type="submit" class="btn btn-primary">Próximo</button>
                </div>
                <?php endif; ?>
            </form>
        <?php endif; ?>
        <?php if(request()->query('code')): ?>
            <form method="POST" action="<?php echo e(route('register.user')); ?>">
                <?php echo csrf_field(); ?>
                <?php if(session('error')): ?>
                    <div class="alert alert-danger alert-dismissible show" role="alert">
                        <span class="alert-icon"><i class="ni ni-like-2"></i></span>
                        <span class="alert-text"><strong>Erro!</strong> <?php echo e(session('error')[0]); ?></span>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php endif; ?>
                <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible show" role="alert">
                        <span class="alert-icon"><i class="ni ni-like-2"></i></span>
                        <span class="alert-text"><strong>Show!</strong> <?php echo e(session('success')[0]); ?></span>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php endif; ?>
                <div class="mt-4">
                    <label for="code"> Matrícula</label>
                    <input <?php if(request()->query('code')): ?> readonly <?php endif; ?> id="code" class="form-control block mt-1 w-full" type="number" name="code" value="<?php echo e(request()->query('code')); ?>" required/>
                </div>

                <div class="mt-4">
                    <label for="name"> Nome</label>
                    <input readonly id="name" class="form-control block mt-1 w-full" type="text" name="name" value="<?php echo e(optional($user)->name); ?>" required/>
                </div>

                <div class="mt-4">
                    <label for="name"> Unidade</label>
                    <input readonly id="unit" class="form-control" type="text" name="unit" value="<?php echo e(optional($user)->unit); ?>" required/>
                </div>

                <div class="mt-4">
                    <label for="phone"> Telefone</label>
                    <input onkeyup="handlePhone(event)" id="phone" class="form-control" type="text" name="phone" required />
                </div>

                <div class="mt-4">
                    <label for="email"> E-mail</label>
                    <input id="email" class="form-control" type="email" name="email" required/>
                </div>

                <!--<div class="mt-4">-->
                <!--    <label for="tshirt"> Tamanho da camiseta</label>-->
                <!--    <select name="tshirt" class="form-control" required>-->
                <!--        <option value="">Selecione um tamanho</option>-->
                <!--        <option value="P">P</option>-->
                <!--        <option value="M">M</option>-->
                <!--        <option value="G">G</option>-->
                <!--        <option value="EX">EX</option>-->
                <!--    </select>-->
                <!--</div>-->
                <div class="card mt-2 " style="font-size: 13px">
                    <div class="card-body">
                        <strong>Corrida virtual 5km - Domingo, Dia 28/05/2023</strong><br>
                        Seu percurso deverá ser registrado por GPS ou aplicativos de corrida e, ser publicado com print de imagem com o tempo da corrida através do link que enviaremos via e-mail.
                        <br>Boa corrida à todos e todas!
                    </div>
                </div>
                <div class="flex items-center justify-end mt-4">
                    <div class="row">
                        <div class="col-6">
                            <a href=" <?php echo e(env('APP_URL')); ?>"><button type="button" class="btn btn-default">Resetar</button></a>
                        </div>
                        <div class="col-6">
                            <button type="submit" class="btn btn-success">Cadastrar</button>
                        </div>
                    </div>
                </div>
            </form>

        <?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<style>
    input:read-only {
        font-weight: bold;
        color: #000;
        background: #ccc
    }
</style>
<script>
    const handlePhone = (event) => {
    let input = event.target
    input.value = phoneMask(input.value)
    }

    const phoneMask = (value) => {
    if (!value) return ""
    value = value.replace(/\D/g,'')
    value = value.replace(/(\d{2})(\d)/,"($1) $2")
    value = value.replace(/(\d)(\d{4})$/,"$1-$2")
    return value
    }
</script><?php /**PATH /home1/cativida/cba.catividade.com.br/resources/views/welcome.blade.php ENDPATH**/ ?>